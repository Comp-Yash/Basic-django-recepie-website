from django.db import models

class student(models.Model):
    # id=models.AutoField()
    name=models.CharField((""), max_length=50)
    age=models.IntegerField()    
    email=models.EmailField((""), max_length=254)
    address=models.TextField(null=True,blank=True)
    image=models.ImageField((""), upload_to=None, height_field=None, width_field=None, max_length=None)
    file=models.FileField((""), upload_to=None, max_length=100)