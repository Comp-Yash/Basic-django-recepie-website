from django.shortcuts import render

from django.http import HttpResponse

def home(request):

    people=[
        {"name":1},
        {"name":2},
        {"name":"m"},

    ]

    # return HttpResponse("any text")
    return render(request ,"index.html",context={'people':people})
