from django.shortcuts import render ,redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate ,login ,logout
from django.contrib.auth.decorators import login_required


@login_required(login_url='/login/')
def add_recepie(request):
    
    # methode 1:
    
    # data=request.POST
    # print(data)

    # methode 2:

    if request.method=="POST":
        data=request.POST
        r=data.get('r_name')
        d=data.get('describe')
        img=request.FILES.get('r_img')
        

        recepie.objects.create(r_name=r  ,  describe=d  ,  r_img=img)

        return redirect('/recepie/')

    querryset=recepie.objects.all()
    context={'recepie':querryset}
    
    return render(request,"recepie.html",context)


def delete_rece(request,id):
    querryset=recepie.objects.get(id=id)
    querryset.delete()
    return redirect('/recepie/')

def update_rece(request,id):
    querryset=recepie.objects.get(id=id)
    if request.method=="POST":
        data=request.POST
        r=data.get('r_name')
        d=data.get('describe')
        img=request.FILES.get('r_img')
        querryset.r_name=r
        querryset.describe=d
        
        if img :
            querryset.r_img=img

        querryset.save()
        return redirect('/recepie/')


    context={'recepie':querryset}

    return render(request,"update_recepie.html",context)





def log_ot(request):
    
    logout(request)
    return redirect('/login/')




def sign_in(request):
    if request.method=="POST":
        data=request.POST
        username=data.get('username')
        password=data.get('password')

        

        if not User.objects.filter(username=username).exists():
            messages.info(request,'username not exist')
            return redirect('/login/')
        

        user=authenticate(username=username,password=password)    

        if user is None :
            messages.info(request,'Invalid credentials')
            return redirect('/login/')
        else:
            login(request,user)
            return redirect('/recepie/')

    return render(request,"login.html")

def sign_up(request):

    if request.method=="POST":
        data=request.POST
        first_name=data.get('first_name')
        last_name=data.get('last_name')
        username=data.get('username')
        password=data.get('password')

        user=User.objects.filter(username=username)

        if user.exists():
            messages.info(request,'username already taken')
            return redirect('/sign/')

        user= User.objects.create(
        first_name=first_name,
        last_name=last_name,
        username=username,
        password=password,
        )
        user.set_password(password)
        user.save()

        messages.info(request,'Account created ')

        return redirect('/sign/')
    
    return render(request,"sign.html")