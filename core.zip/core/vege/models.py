from django.db import models
from django.contrib.auth.models import User


class recepie(models.Model):

    user = models.ForeignKey(User,on_delete=models.CASCADE,null=True,blank=True)

    r_name=models.CharField(max_length=100)
    describe=models.TextField()
    r_img=models.ImageField(upload_to="Recepie", height_field=None, width_field=None, max_length=None)